<div class="wrap">
    <h1>REST API Route Tester</h1>
    <div id="wprrt-app">
        <div id="wprrt-routes-container">
            <p><strong>Loading routes...</strong></p>
        </div>
    </div>
</div>
