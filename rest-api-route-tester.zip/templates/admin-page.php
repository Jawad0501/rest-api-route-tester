<div class="wrap">
    <h1>WP REST Route Tester</h1>
    <div id="wprrt-app">
        <div id="wprrt-routes-container">
            <p><strong>Loading routes...</strong></p>
        </div>
    </div>
</div>
